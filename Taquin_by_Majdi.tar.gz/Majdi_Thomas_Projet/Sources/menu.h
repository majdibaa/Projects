/* BAAZIZ Majdi
   QUERNEC Thomas  */
#ifndef MENU_H
#define MENU_H
#define TAILLE 5


int choix_lignes();
int choix_lignes_souris();
int choix_colonnes_souris();
int choix_colonnes_n();
int choix_image_clic();
int choix_image();
int ecran_accueil();
#endif
