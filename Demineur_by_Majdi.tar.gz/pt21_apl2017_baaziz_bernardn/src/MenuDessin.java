import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.image.BufferedImage;

/**
 * La classe <code>MenuDessin</code> concerne l'affichage du menu de depart
 * avec les boutons images nouvelle partie et reprendre et quitter.
 *
 * @version 0.1
 * @author Majdi Baaziz et Nathan Bernard
 */
public class MenuDessin extends JComponent {
	/**
	 * Image du bouton Nouvelle partie.
	 */
	private Image jouer;
	/**
	 * Image du bouton Quitter.
	 */
	private Image quitter;
	/**
	 * Image du bouton Reprendre.
	 */
	private Image reprendre;
	/**
	 * Fenetre du menu
	 */
	private FenMenu j;
	public MenuDessin(FenMenu b){
		super();
		this.j=b;
		this.jouer=Toolkit.getDefaultToolkit().getImage("../img/jouer.png");
		this.quitter=Toolkit.getDefaultToolkit().getImage("../img/quitter.png");
		this.reprendre=Toolkit.getDefaultToolkit().getImage("../img/reprendre.png");
	}
	@Override
	/**
	 * On affiche tout le menu et on traite le cas pour rendre le bouton reprendre
	 * gris en fonction si le fichier de sauvegarde contient des octets ou non.
	 */
	public void paintComponent(Graphics pinceau) {
		Graphics secondPinceau = pinceau.create();
		if (this.isOpaque()) { 
			secondPinceau.setColor(this.getBackground());
			secondPinceau.fillRect(0, 0, this.getWidth(), this.getHeight());
		}
		secondPinceau.drawImage(Toolkit.getDefaultToolkit().getImage("../img/demineur.png"),0,0,this);
		secondPinceau.drawImage(this.jouer,130,220,this);
		if(this.TestFichier()!=0){
			secondPinceau.drawImage(this.reprendre,204,320,this);
		}else{
			secondPinceau.drawImage(Toolkit.getDefaultToolkit().getImage("../img/reprendre2.png"),204,320,this);
		}
		secondPinceau.drawImage(this.quitter,234,430,this);
	}
	/**
	 * Methode qui gere la surbrillance des bouton nouvelle partie, reprendre et quitter.
	 */
	public void Redessin(int x, int y){
		if(x>=130 && x<=530 && y>=(220+26) && y<=(273+26)){
			this.jouer=Toolkit.getDefaultToolkit().getImage("../img/jouer1.png");
		}else{
			this.jouer=Toolkit.getDefaultToolkit().getImage("../img/jouer.png");
		}
		if(x>=204 && x<=467 && y>=(320+26) && y<=(373+26)){
			this.reprendre=Toolkit.getDefaultToolkit().getImage("../img/reprendre1.png");
		}else{
			this.reprendre=Toolkit.getDefaultToolkit().getImage("../img/reprendre.png");
		}
		if(x>=234 && x<=427 && y>=(430+26) && y<=(473+26)){
			this.quitter=Toolkit.getDefaultToolkit().getImage("../img/quitter1.png");
		}else{
			this.quitter=Toolkit.getDefaultToolkit().getImage("../img/quitter.png");
		}
		this.repaint();
	}
	/**
	 * Methode qui retourne le nombre d'octets du fichier de sauvegarde.
	 */
	private int TestFichier(){
		try{
			DataInputStream x = new DataInputStream(new FileInputStream("log"));
			try{
				return x.available();
			}catch(IOException e){}
		}catch(FileNotFoundException e){}
		return 0;
	}
	/**
	 * Methode appelee lorsque un bouton est appuye, permet d'appeler la methode Launch lorsque nouvelle partie est clique
	 * ou alors avec le bouton Reprendre lorsque le fichier de sauvegarde contient des octets (une sauvegarde) de recuperer les donnees de ce fichier
	 * et de lancer le jeu directement apres. Quitte le jeu lorsque Quitter est appuye.
	 */
	public void Commencement(int x, int y){
		if(x>=130 && x<=530 && y>=(220+26) && y<=(273+26)){
			this.Launch();
		}
		if(x>=204 && x<=467 && y>=(320+26) && y<=(373+26)){
			try{
				DataInputStream lecture = new DataInputStream(new FileInputStream("log"));
				try{
					if(lecture.available()>0){
						int lig=lecture.readInt();
						int col=lecture.readInt();
						int aleatoire=lecture.readInt();
						char[][] chr = new char[lig][col];
						char[][] ouvertoupas=new char[lig][col];
						boolean[][] alea = new boolean[lig][col];
						for(int i=0;i<lig;i++){
							for(int j=0;j<col;j++){
								chr[i][j]=lecture.readChar();
							}
						}
						for(int i=0;i<lig;i++){
							for(int j=0;j<col;j++){
								ouvertoupas[i][j]=lecture.readChar();
							}
						}
						for(int i=0;i<lig;i++){
							for(int j=0;j<col;j++){
								alea[i][j]=lecture.readBoolean();
							}
						}
						JFr truc = new JFr(new Fenetre(lig,col,aleatoire,alea,ouvertoupas,chr));
						truc.setVisible(true);
						this.j.dispose();
					}
					lecture.close();
				}catch(IOException e){}
			}catch(IOException e){}
		}
		if(x>=234 && x<=427 && y>=(430+26) && y<=(473+26)){
			System.exit(0);
		}
	}
	/**
	 * Lance le choix des lignes et colonnes en ajoutant le panneau FenChoix a la fenetre existante.
	 *
	 */
	private void Launch(){
		FenChoix b = new FenChoix(this.j);
		b.setSize(651,651);
		b.setLocation(0,0);
		this.add(b);
	}
}
