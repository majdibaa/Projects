import javax.swing.JComponent;
import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.image.BufferedImage;
/**
 * La classe <code>Main</code> appelle la fenetre du menu du jeu.
 *
 * @version 0.1
 * @author Majdi Baaziz et Nathan Bernard
 */
public class Main{
	public static void main(String[] args){
		FenMenu x = new FenMenu();
		x.setVisible(true);
	}
}