import javax.swing.JComponent;
import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.image.BufferedImage;
import java.awt.event.*;
/**
 * La classe <code>WindowControl</code> permet l'enregistrement de la partie
 * lorsque le joueur clique sur la croix de la fenetre.
 *
 * @version 0.1
 * @author Majdi Baaziz et Nathan Bernard
 */
public class WindowControl implements WindowListener{
	private JFr u;
	public WindowControl(JFr fenetre){
		this.u=fenetre;
	}
	@Override
	public void windowActivated(WindowEvent evenement){}
	@Override      
	public void windowClosed(WindowEvent evenement){}         
	@Override
	public void windowClosing(WindowEvent evenement){
		this.u.Enregistrement();
	}        
	@Override
	public void windowDeactivated(WindowEvent evenement){}    
	@Override
	public void windowDeiconified(WindowEvent evenement){}   
	@Override 
	public void windowIconified(WindowEvent evenement){}     
	@Override
	public void windowOpened(WindowEvent evenement){}         
}