import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;
/**
 * La classe <code>Mousemotion</code> concerne le controleur qui gere le type de clique
 * realise sur la fenetre de jeu. En fonction du clique il realisera une action :
 * pour un clique droit il rentrera dans la methode pour poser un drapeau ou un point d'interrogation
 * si c'est un clique gauche il traitera les cas pour l'ouverture d'une case.
 *
 * @version 0.1
 * @author Majdi Baaziz et Nathan Bernard
 */
public class Mousemotion implements MouseListener{
	/**
	 * Panneau de jeu.
	 */
	public Fenetre j;
	public Mousemotion(Fenetre b){
		this.j=b;
	}
	/**
	 * Traite les cas du clique gauche et du clique droit et appelle les fonctions en consequence.
	 */
	@Override
	public void mouseClicked(MouseEvent e){
		if(e.getModifiers()==16){
			this.j.Clique(e.getX(),e.getY());
		}else if(e.getModifiers()==4){
			this.j.Drapeau(e.getX(),e.getY());
		}
	}
	@Override
	public void mouseEntered(MouseEvent e){}
	@Override
	public void mouseExited(MouseEvent e){
	}
	@Override
	public void mousePressed(MouseEvent e){
		
		
	}         
	@Override
	public void mouseReleased(MouseEvent e){
	} 
}